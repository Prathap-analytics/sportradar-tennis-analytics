"""Fetch tennis data from Sportradar API and flatten it into DataFrames."""

import os
import time
import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("SPORTRADAR_API_KEY")

# Standard Tennis v3 Trial Base URL
BASE_URL = "https://api.sportradar.com/tennis/trial/v3/en"


def call_api(endpoint: str, retries: int = 3) -> dict:
    """Call an endpoint and return JSON response."""
    url = f"{BASE_URL}/{endpoint}"
    params = {"api_key": API_KEY}

    # Browser User-Agent header prevents 10054 ConnectionReset Error
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json",
    }

    for attempt in range(retries):
        try:
            response = requests.get(
                url, params=params, headers=headers, timeout=30
            )

            # Handle rate limiting
            if response.status_code == 429:
                print("Rate limit hit, waiting 5 seconds...")
                time.sleep(5)
                continue

            response.raise_for_status()
            time.sleep(1.5)  # Stay under free tier rate limits
            return response.json()

        except requests.exceptions.RequestException as error:
            print(f"Attempt {attempt + 1} failed for {endpoint}: {error}")
            time.sleep(3)

    raise RuntimeError(f"Could not fetch {endpoint} after {retries} attempts.")


def get_competitions():
    """Fetch competitions and extract categories and competitions DataFrames."""
    data = call_api("competitions.json")
    categories = {}
    competitions = []

    for item in data.get("competitions", []):
        category = item.get("category", {})
        if category.get("id"):
            categories[category.get("id")] = category.get("name")

        competitions.append(
            {
                "competition_id": item.get("id"),
                "competition_name": item.get("name"),
                "parent_id": item.get("parent_id"),  # May be None for top-level
                "type": item.get("type"),
                "gender": item.get("gender"),
                "category_id": category.get("id"),
            }
        )

    categories_df = pd.DataFrame(
        [{"category_id": k, "category_name": v} for k, v in categories.items()]
    )
    competitions_df = pd.DataFrame(competitions)

    return categories_df, competitions_df


def get_complexes():
    """Fetch complexes and extract complexes and venues DataFrames."""
    data = call_api("complexes.json")
    complexes = []
    venues = []

    for complex_item in data.get("complexes", []):
        complexes.append(
            {
                "complex_id": complex_item.get("id"),
                "complex_name": complex_item.get("name"),
            }
        )

        for venue in complex_item.get("venues", []):
            venues.append(
                {
                    "venue_id": venue.get("id"),
                    "venue_name": venue.get("name"),
                    "city_name": venue.get("city_name"),
                    "country_name": venue.get("country_name"),
                    "country_code": venue.get("country_code"),
                    "timezone": venue.get("timezone"),
                    "complex_id": complex_item.get("id"),
                }
            )

    return pd.DataFrame(complexes), pd.DataFrame(venues)


def get_doubles_rankings():
    """Fetch doubles rankings and extract competitors and rankings DataFrames."""
    data = call_api("double_competitors_rankings.json")
    competitors = {}
    rankings = []
    rank_counter = 1  # Counter to generate a unique rank_id for every row

    for ranking_list in data.get("rankings", []):
        for entry in ranking_list.get("competitor_rankings", []):
            competitor = entry.get("competitor", {})
            comp_id = competitor.get("id")

            if comp_id:
                competitors[comp_id] = {
                    "competitor_id": comp_id,
                    "name": competitor.get("name"),
                    "country": competitor.get("country"),
                    "country_code": competitor.get("country_code"),
                    "abbreviation": competitor.get("abbreviation"),
                }

            rankings.append(
                {
                    "rank_id": rank_counter,  # Automatically assigns 1, 2, 3, ...
                    "rank": entry.get("rank"),
                    "movement": entry.get("movement"),
                    "points": entry.get("points"),
                    "competitions_played": entry.get("competitions_played"),
                    "competitor_id": comp_id,
                }
            )
            rank_counter += 1  # Increment for the next entry

    competitors_df = pd.DataFrame(list(competitors.values()))
    rankings_df = pd.DataFrame(rankings)

    return competitors_df, rankings_df


if __name__ == "__main__":
    print("Starting data extraction...")

    categories_df, competitions_df = get_competitions()
    complexes_df, venues_df = get_complexes()
    competitors_df, rankings_df = get_doubles_rankings()

    tables = {
        "categories": categories_df,
        "competitions": competitions_df,
        "complexes": complexes_df,
        "venues": venues_df,
        "competitors": competitors_df,
        "competitor_rankings": rankings_df,
    }

    for name, df in tables.items():
        df.to_csv(f"{name}.csv", index=False)
        print(f"Saved {name}.csv ({len(df)} rows)")

    print("Data extraction complete!")