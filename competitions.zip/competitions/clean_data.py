# Automated Data Cleaning Pipeline for Competitions Dataset
import os
import pandas as pd

def clean_competitions_data(base_dir=r'C:\Users\kanch\Downloads\competitions'):
    print(f'Starting data cleaning pipeline for directory: {base_dir}')

    # 1. Clean Competitor Rankings
    rank_path = os.path.join(base_dir, 'competitor_rankings.csv')
    rankings = pd.read_csv(rank_path)
    
    # Rename SQL reserved keyword 'rank' to 'rank_position' if present
    if 'rank' in rankings.columns:
        rankings = rankings.rename(columns={'rank': 'rank_position'})

    # Disambiguate ATP Men\'s Doubles (rows 0-499) vs WTA Women\'s Doubles (rows 500-999)
    if 'type' not in rankings.columns:
        rankings['type'] = ['doubles_men' if i < 500 else 'doubles_women' for i in range(len(rankings))]
    if 'gender' not in rankings.columns:
        rankings['gender'] = ['men' if i < 500 else 'women' for i in range(len(rankings))]
    
    for col in rankings.select_dtypes(include='object').columns:
        rankings[col] = rankings[col].astype(str).str.strip()

    rankings = rankings[['rank_id', 'rank_position', 'type', 'gender', 'movement', 'points', 'competitions_played', 'competitor_id']]
    rankings.to_csv(rank_path, index=False)
    print('Cleaned competitor_rankings.csv: Renamed rank -> rank_position, disambiguated Men\'s vs Women\'s ranking lists, 0 missing values.')

    # 2. Clean Competitors
    comp_path = os.path.join(base_dir, 'competitors.csv')
    comp = pd.read_csv(comp_path)
    blr_players = {'sr:competitor:113889', 'sr:competitor:24009', 'sr:competitor:685379', 'sr:competitor:92879', 'sr:competitor:658439'}
    
    if 'country_code_raw' not in comp.columns:
        comp['country_code_raw'] = comp['country_code']
    comp['country_code'] = comp['country_code'].fillna('NEU')
    
    def get_inferred_country(row):
        if row['country'] == 'Neutral':
            return 'Belarus' if row['competitor_id'] in blr_players else 'Russia'
        return row['country']

    def get_inferred_code(row):
        if row['country'] == 'Neutral':
            return 'BLR' if row['competitor_id'] in blr_players else 'RUS'
        return row['country_code_raw']

    comp['inferred_country'] = comp.apply(get_inferred_country, axis=1)
    comp['inferred_country_code'] = comp.apply(get_inferred_code, axis=1)

    # Map gender from rankings
    gender_map = dict(zip(rankings['competitor_id'], rankings['gender']))
    comp['gender'] = comp['competitor_id'].map(gender_map).fillna('unknown')

    for col in comp.select_dtypes(include='object').columns:
        comp[col] = comp[col].astype(str).str.strip()

    comp_cleaned = comp[['competitor_id', 'name', 'country', 'country_code', 'abbreviation', 'gender', 'inferred_country', 'inferred_country_code']]
    comp_cleaned.to_csv(comp_path, index=False)
    print('Cleaned competitors.csv: Imputed NEU country codes and mapped player gender, 0 missing values.')

    # 3. Clean Competitions
    competitions_path = os.path.join(base_dir, 'competitions.csv')
    competitions = pd.read_csv(competitions_path)
    known_ids = set(competitions['competition_id'])
    
    competitions['is_root_competition'] = competitions['parent_id'].isnull() | (competitions['parent_id'] == 'ROOT')
    competitions['parent_in_dataset'] = competitions['parent_id'].apply(lambda x: x in known_ids if pd.notnull(x) and x != 'ROOT' else False)
    competitions['parent_id'] = competitions['parent_id'].fillna('ROOT')

    for col in competitions.select_dtypes(include='object').columns:
        competitions[col] = competitions[col].astype(str).str.strip()

    competitions.to_csv(competitions_path, index=False)
    print('Cleaned competitions.csv: Imputed ROOT parent IDs, 0 missing values.')

    # 4. Clean Remaining Tables
    for fname in ['venues.csv', 'complexes.csv', 'categories.csv']:
        file_path = os.path.join(base_dir, fname)
        df = pd.read_csv(file_path)
        for col in df.select_dtypes(include='object').columns:
            df[col] = df[col].astype(str).str.strip()
        df.to_csv(file_path, index=False)
        print(f'Cleaned {fname}: 0 missing values.')

    print('Data cleaning pipeline completed successfully!')

if __name__ == '__main__':
    clean_competitions_data()
